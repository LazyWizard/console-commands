package org.lazywizard.console.commands;

import org.lazywizard.sfconsole.BaseCombatHook;
import org.lazywizard.sfconsole.BaseCommand;

public class NoCooldown implements BaseCommand
{
    @Override
    protected String getHelp()
    {
        return "Toggles weapon cooldowns for all ships on your side.";
    }

    @Override
    protected String getSyntax()
    {
        return "nocooldown (no arguments)";
    }

    @Override
    protected boolean isUseableInCombat()
    {
        return true;
    }

    @Override
    public CommandResult runCommand(String args, CommandContext context)
    {
        BaseCombatHook.toggleNoCooldown();
        return true;
    }
}
