package org.lazywizard.console.commands;

import org.lazywizard.sfconsole.BaseCommand;
import org.lazywizard.sfconsole.Console;

public class Alias implements BaseCommand
{
    @Override
    protected boolean runCommand(String args)
    {
        /*String[] tmp = args.split(" ");

        if (tmp.length < 2)
        {
            showSyntax();
            return false;
        }
        else if (tmp[0].equalsIgnoreCase("alias") || tmp[1].equalsIgnoreCase("alias"))
        {
            Console.showMessage("Nice try!");
            return false;
        }


        String alias = tmp[0];
        StringBuilder arg = new StringBuilder();

        for (int x = 1; x < tmp.length; x++)
        {
            if (x != 1)
            {
                arg.append(" ");
            }

            arg.append(tmp[x]);
        }

        String command = arg.toString();

        if (!Console.addAlias(alias, command))
        {
            Console.showMessage("Alias failed! Does this alias already exist as a command?");
            return false;
        }

        Console.showMessage("'" + alias + "' successfully aliased for '" + command + "'.");
        return true;*/

        return false;
    }
}
