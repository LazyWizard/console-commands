package org.lazywizard.console.commands;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoAPI.CargoItemType;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import org.lazywizard.sfconsole.BaseCommand;
import org.lazywizard.sfconsole.Console;
import java.util.List;

public class AllWeapons implements BaseCommand
{
    private static final String STATION = "Abandoned Storage Facility";
    private static final float STACK_SIZE = 10f;
    
    @Override
    public CommandResult runCommand(String args, CommandContext context)
    {
        SectorEntityToken target;

        float amount = STACK_SIZE;
        float total = 0;

        if (args == null || args.isEmpty())
        {
            args = STATION;
        }

        target = Global.getSector().getCurrentLocation().getEntityByName(args);

        if (target == null)
        {
            Console.showMessage(args + " not found! Defaulting to player cargo.");
            target = Global.getSector().getPlayerFleet();
            amount = 1f;
        }

        CargoAPI cargo = target.getCargo();
        List allWeapons = Global.getSector().getAllWeaponIds();

        for (int x = 0; x < allWeapons.size(); x++)
        {
            cargo.addItems(CargoItemType.WEAPONS, allWeapons.get(x), amount);
            total += amount;
        }

        Console.showMessage("Added " + total + " items to " + target.getFullName() + ".");
        return true;
    }
}
