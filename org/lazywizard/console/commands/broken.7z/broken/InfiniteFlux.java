package org.lazywizard.console.commands;

import org.lazywizard.sfconsole.BaseCombatHook;
import org.lazywizard.sfconsole.BaseCommand;

public class InfiniteFlux implements BaseCommand
{
    @Override
    protected String getHelp()
    {
        return "Toggles infinite flux for all ships on your side.";
    }

    @Override
    protected String getSyntax()
    {
        return "infiniteflux (no arguments)";
    }

    @Override
    protected boolean isUseableInCombat()
    {
        return true;
    }

    @Override
    public CommandResult runCommand(String args, CommandContext context)
    {
        BaseCombatHook.toggleInfiniteFlux();
        return true;
    }
}