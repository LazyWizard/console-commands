package org.lazywizard.console.commands;

import org.lazywizard.sfconsole.BaseCombatHook;
import org.lazywizard.sfconsole.BaseCommand;

public class God implements BaseCommand
{
    @Override
    protected boolean isUseableInCombat()
    {
        return true;
    }

    @Override
    public CommandResult runCommand(String args, CommandContext context)
    {
        BaseCombatHook.toggleGodMode();
        return true;
    }
}