package org.lazywizard.console.commands;

import org.lazywizard.sfconsole.BaseCombatHook;
import org.lazywizard.sfconsole.BaseCommand;

public class Reveal implements BaseCommand
{
    @Override
    protected String getHelp()
    {
        return "Toggles fog of war on the battle map.";
    }

    @Override
    protected String getSyntax()
    {
        return "reveal (no arguments)";
    }

    @Override
    protected boolean isUseableInCombat()
    {
        return true;
    }

    @Override
    public CommandResult runCommand(String args, CommandContext context)
    {
        BaseCombatHook.toggleReveal();
        return true;
    }
}
