package org.lazywizard.sfconsole.commands;

import org.lazywizard.sfconsole.BaseCombatHook;
import org.lazywizard.sfconsole.BaseCommand;

public class InfiniteFlux extends BaseCommand
{
    @Override
    protected String getHelp()
    {
        return "Toggles infinite flux for all ships on your side.";
    }

    @Override
    protected String getSyntax()
    {
        return "infiniteflux (no arguments)";
    }

    @Override
    protected boolean isUseableInCombat()
    {
        return true;
    }

    @Override
    public boolean runCommand(String args)
    {
        BaseCombatHook.toggleInfiniteFlux();
        return true;
    }
}